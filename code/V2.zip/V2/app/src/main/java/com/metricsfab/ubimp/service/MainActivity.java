package com.metricsfab.ubimp.service;


import android.os.Bundle;
import android.view.MenuItem;



import com.google.android.material.navigation.NavigationView;
import com.metricsfab.ubimpservice.R;
import com.metricsfab.utils.playServices.IDialogCancelListener;
import com.metricsfab.utils.ui.IOnEventListener;

public class MainActivity extends AppCompatActivity implements
        IDialogCancelListener,
        NavigationView.OnNavigationItemSelectedListener,
        IOnEventListener
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem)
    {
        return false;
    }


    @Override
    public void OnDialogCancel()
    {

    }


    @Override
    public void onEventSwitch(boolean param1Boolean)
    {

    }
}
