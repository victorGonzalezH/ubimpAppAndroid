package com.metricsfab.utils.http;

import org.json.JSONObject;

public interface IRestApiOperationCompleted
{
    void completed(JSONObject paramJSONObject);
}
