package com.metricsfab.utils.ui;


public interface IOnEventListener
{
    void onEventSwitch(boolean param1Boolean);
}
