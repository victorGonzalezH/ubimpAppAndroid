package com.metricsfab.utils.playServices;


public interface IDialogCancelListener
{
    void OnDialogCancel();
}
