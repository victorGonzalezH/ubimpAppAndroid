package com.metricsfab.utils.net;

public interface ITcpMessageListener
{
    void onReceiveTcpMessage(String paramString);
}
